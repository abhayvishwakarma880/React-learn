
import './App.css'
import './main.css'

function App() {

  return (
    <div>
      <h1 className='h1'>Welcom to React</h1>
      <p>Hello I`am Noob in BGMI .</p>
    </div>
  )
}

export default App
