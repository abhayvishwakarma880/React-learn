function w(){
  return(
    <div>
      <h1>Helllow This is new Page</h1>
    </div>
  )
}
export default w;