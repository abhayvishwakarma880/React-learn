function Props(props){
  return (
    <div>
      <h1>Hellow, {props.name}</h1>
      <h2>{props.name} is {props.role}</h2>
    </div>
  );
}
export default Props;
