import React from "react";
import Login from "./Login";
import { Link } from "react-router-dom";

function Home(){
  return (
    <div>
      <Login /> <br />
      {/* <Link to="signup">signup</Link> */}
    </div>
  );
};
export default Home;